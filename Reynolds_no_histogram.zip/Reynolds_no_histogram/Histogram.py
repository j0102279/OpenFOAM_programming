'''
PLOTTING THE FREQUENCY DENSITY OF THE VALUES OF THE REYNOLDS NUMBER ACROSS ALL 
                          CELLS IN THE FLUID DOMAIN
-------------------------------------------------------------------------------

This program takes as input a .txt file containing a list of Reynolds numbers
across all cells within the fluid domain. This text file was obtained by hard
coding the equations for the Reynolds number into the transient icoFoam solver
in OpenFOAM. When the solver was called, a file was written out for each 
time-step containing the calculated value of the Reynolds number at all points
in the fluid domain. Before inputting it into this program, the decorative 
rubbish at both the top and bottom of the .txt file needs to be deleted, so
it's purely Re values.

The list is then read and formatted into a numPy array, before being plotted 
into a histogram to show the frequemcy density of the value of the Reynolds
number.

The intention of this program is to help determine a set of intial conditions
which give a frequency density of the Reynolds number, which almost entirely 
falls below the turbulent transition value (Re = 2040).

'''




import numpy as np
import matplotlib.pyplot as plt




#-----------------------------------------------------------------------------#
"""
Opens the file specified by the user and formats each entry into a floating 
point number, before appending it to the list of entries. Finally, the list of
entries is placed into a numPy array, as this is required to plot it as a 
histogram.
"""

print('Remember to delete all of the redundant parts of the text file produced by OpenFOAM')

filename= input('Enter a filename to read in: ')



with open(filename, 'r') as Re_in:
    
    file_formatted = []
    no_corrupted = 0
    no_excluded = 0
 
    
    for line in Re_in:
     
        try:
            sanitised_line = float(line.strip())
        except:
            no_corrupted +=1
            continue
     
        if sanitised_line>100000:
            no_excluded +=1
            continue
        
        file_formatted.append(sanitised_line)
 
 
values = np.array(file_formatted)
    




#-----------------------------------------------------------------------------#
"""
Printing some info on the amount of data processed, and checking all the
lines were valid.
"""
    
print("Data pieces included: ", len(file_formatted))
print('Data pieces excluded: ', no_excluded)
print('Number of corrupted lines: ', no_corrupted)





#-----------------------------------------------------------------------------#
"""
Plotting the graph and saving it as a PDF.
"""
    
plt.hist(values, bins = 85)
plt.axvline(x=2040, color='r', linestyle='--', lw=1.1, label='Turbulence transition')
    
plt.title('Histogram of Reynolds Number Within Mesh Cells')
plt.xlabel('Reynolds number [-]')
plt.ylabel('Frequency [-]')
plt.xlim(0,)
plt.ylim(0,)
plt.grid(which='major', linestyle='-', linewidth='0.7')
plt.grid(which='minor', linestyle='dashed', linewidth='0.4')
plt.savefig(('Reynolds_no_frequency.pdf'))
plt.show()