'''
  OBJECTIVELY DETERMINING THE LENGTH REQUIRED TO REACH STEADY STATE FLOW
-------------------------------------------------------------------------------

This program takes a set of OpenFOAM U files from consecutive time-steps as 
input. Before inputting it into this program, the decorative rubbish at both
the top and bottom of the .txt file needs to be deleted, so it's purely Re
values. It also asks for the inflow velocity of the case, so it can calculate

The intention of this program is to determine 

'''



import numpy as np
import matplotlib.pyplot as plt







#-----------------------------------------------------------------------------#
"""

"""

inflow_velocity = float(input('Enter an inflow velocity for the case: '))



filenames = []
velocity_magnitude_time_steps = []

while True:

    filename_velocity= input('Enter a velocity filename to read in: ')
    filenames.append(filename_velocity)
    
    if filename_velocity == 'done':
        break
    
    
    
    with open(filename_velocity, 'r') as velocity_in:
    

        vel_magnitude_list = []
        num_velocity_corrupted = 0
 

        for line in velocity_in:
     
            
            sanitised_line = [str(a) for a in line.strip().split()]
                
            x_vel = sanitised_line[0]
            x_vel = float(x_vel[1:])
                
            y_vel = float(sanitised_line[1])
                
            z_vel = sanitised_line[2]
            z_vel = float(z_vel[:-1])
                
            vel_magnitude = (((x_vel**2 + y_vel**2)**0.5) + z_vel**2) **0.5
        

            vel_magnitude_list.append(vel_magnitude)
    
    
    velocity_magnitude_time_steps.append(vel_magnitude_list)







#-----------------------------------------------------------------------------#
"""

"""

delta_total_list = []
delta_averages_list = []
delta_average_percentages_list = []

inflow_velocity_array = np.full(len(vel_magnitude_list), inflow_velocity)

for current_step in range(len(filenames)-2):
    
    n = np.array(velocity_magnitude_time_steps[current_step])
    n1 = np.array(velocity_magnitude_time_steps[current_step + 1])
    delta_velocity_array = n1 - n
    
    
    delta_total = 0
    
    for i in range(len(delta_velocity_array)):
        delta_total += delta_velocity_array[i]
    
    delta_av = delta_total/len(delta_velocity_array)
    average_as_inflow_percentage = ((delta_av/inflow_velocity)*100)
    
    delta_averages_list.append(float(delta_av))
    delta_total_list.append(float(delta_total))
    delta_average_percentages_list.append(average_as_inflow_percentage)
    
    


    
   #-----------------------------------------------------------------------------#
"""
Writing out the the data to a file.
"""
 
with open('average_velocity_change_between_steps.txt', 'w') as av_out:
    

        av_out.write('{:^25s}'.format('Time-step'))
        av_out.write(' ')
        av_out.write('{:^25s}'.format('Average Δ velocity mag'))
        av_out.write(' ')
        av_out.write('{:^25s}'.format('(As % of inflow)'))
        av_out.write(' ')
        av_out.write('{:^25s}'.format('Total Δ velocity mag'))
        av_out.write('\n\n')
        
        
        #Loop writes out all 4 columns for each jump between time-steps
        for i in range(len(delta_averages_list)):
            
            entry1 = filenames[i] + ' to ' + filenames[i+1]
            entry2 = float(delta_averages_list[i])
            entry3 = float(delta_average_percentages_list[i])
            entry4 = float(delta_total_list[i])
            
            av_out.write('{:>25s}'.format(entry1))
            av_out.write('{:>25e}'.format(entry2))
            av_out.write('{:>25f}'.format(entry3))
            av_out.write('{:>25e}'.format(entry4))
            av_out.write('\n')
        
        
        
        

#-----------------------------------------------------------------------------#
"""

"""

time_entries = []

for entry in filenames:
    
    if entry == 'done':
        break
    
    corrected_entry = []
    
    for character in entry:
        
        if character == '_':
            corrected_entry.append('.')
        elif character == '.':
            break
        else:
            corrected_entry.append(character)
    
    corrected_entry_string = ''
    
    for i in corrected_entry:
        corrected_entry_string += str(i)
        
    corrected_entry_float = float(corrected_entry_string)
    time_entries.append(corrected_entry_float)





#-----------------------------------------------------------------------------#
"""

"""

time_entry_midpoints = []

for i in range(len(time_entries)-1):
    
    midpoint = (time_entries[i] + time_entries[i+1]) / 2
    time_entry_midpoints.append(float(midpoint))






  #-----------------------------------------------------------------------------#
"""
Plotting the graph and saving it as a PDF.
"""
      
plt.scatter(time_entry_midpoints, delta_averages_list)
plt.plot(time_entry_midpoints, delta_averages_list)

plt.title('Plot of time taken to reach steady state flow')
plt.xlabel('Time [s]')
plt.ylabel('Average ΔUmag across all cells [m/s]')
plt.xlim(0, 0.008)
plt.ylim(0, 0.004)
plt.grid(which='major', linestyle='-', linewidth='0.7')
plt.grid(which='minor', linestyle='dashed', linewidth='0.4')
plt.savefig(('Steady_state.pdf'))
plt.show()