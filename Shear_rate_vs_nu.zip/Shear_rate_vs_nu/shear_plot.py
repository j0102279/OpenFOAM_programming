'''
        PLOTTING VISCOSITY VS SHEAR RATE FROM DATA FILES PRODUCED BY 
                         AN OPENFOAM SIMULATION
-------------------------------------------------------------------------------

This program takes as input two .txt files. 

The first contains a list of shear rate values across all cells within the 
fluid domain. This text file was obtained by hard coding the equations for the 
shear rate into the transient icoFoam solver in OpenFOAM. It was programmed in
as a scalar field. When the solver was called, a file was written out for each 
time-step containing the calculated value of the shear rate at all points
in the fluid domain.

The second contains a list of viscosity values (nu) across all cells within the 
fluid domain. Nu was also hard coded into the solver, to produce a continually
evolving field rather than a constant scalar value.

Before inputting them into this program, the decorative rubbish at both the top
and bottom of the .txt files needs to be deleted, soit's purely values.

The files are then read and formatted into list variables, before being 
plotted. The intention of this program is to see the changes in nu produced 
by the modified solver, depending on the rate of the strain tensor at different
points within the fluid domain. This can be directly compared to experimental
data from other studues to confirm that the modified solver produces valid
results.

'''





import matplotlib.pyplot as plt





#----------------------------------------------------------------------------#
"""
Opens the files specified by the user and formats each entry into a floating 
point number, before appending it to the respective list of entries.
"""


filename_shear = input('Enter a rate of strain filename to read in: ')
filename_nu = input('Enter a nu filename to read in: ')
user_log = input('Logarithmic axis? [y/n]: ')


with open(filename_shear, 'r') as shear_in, open(filename_nu, 'r') as nu_in:
    
    #Initialising empty lists outside of the loops
    shear_formatted = []
    nu_formatted = []
    
    #Initialising the counters for any possible corrupted data
    num_shear_corrupted = 0
    num_nu_corrupted = 0

    
    #Loop to form list of shear values as floating point numbers
    for line in shear_in:
    
        try:
            sanitised_line = (float(line.strip()))**0.5
        except:
            num_shear_corrupted +=1
            continue
        
        shear_formatted.append(sanitised_line)
    
    
    #Loop to form list of viscosity values as floating point numbers
    for line in nu_in:
    
        try:
            sanitised_line = float(line.strip())
        except:
            num_nu_corrupted +=1
            continue
        
        nu_formatted.append(sanitised_line)





 #----------------------------------------------------------------------------#
"""
Printing some info on the amount of data processed, and checking all the
lines were valid.
"""
    
print("Number of shear data pieces included: ", len(shear_formatted))
print('Number of corrupted shear data pieces: ', num_shear_corrupted)
print("Number of nuu data pieces included: ", len(nu_formatted))
print('Number of corrupted shear data pieces: ', num_nu_corrupted)





#----------------------------------------------------------------------------#
"""
Plotting the graph and saving it to PDF.
"""

plt.scatter(shear_formatted, nu_formatted)

if user_log == 'y':
    plt.xscale('log')
    plt.yscale('log')
    
plt.title('Plot of nu vs Shear rate')
plt.xlabel('Rate of strain tensor [s$^-$$^1$]')
plt.ylabel('nu [Pa.s]')
plt.xlim(0, )
plt.ylim(0.0001, 0.001)
plt.grid(which='major', linestyle='-', linewidth='0.7')
plt.grid(which='minor', linestyle='dashed', linewidth='0.4')
plt.savefig(('nu_vs_shear_rate.pdf'))
plt.show()