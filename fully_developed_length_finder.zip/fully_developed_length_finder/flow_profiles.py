'''
  OBJECTIVELY DETERMINING THE LENGTH REQUIRED TO REACH FULLY DEVELOPED FLOW
-------------------------------------------------------------------------------

This program takes as input a data file exported from a central slice of the 
domain in paraView (requiring very slight modification).

It will be exported as a CSV file with titles at the top of each column. This 
should be opened in excel, the title row removed, and saved as as tab delimited
text file (.txt). 
The order of the columns should be default, as below...
[p], [U0], [U1], [U2], [Points0], [Points1], [Points2] 

Program will ask the user how far into the domain to investigate, and how many
intervals to divide this into.

It will then plot a graph of the average longitudinal velocity across the flow
profile, at each of the intervals the user has specified, to show how this
develops and stabilises as the flow reaches fully developed.

Finally, the user is asked for a tolerance for the % slope in average velocity 
between intervals. Once the change drops below this tolerance, the flow will
be considered fully developed. The position where this occurs will be printed
to the screen.

'''



import matplotlib.pyplot as plt
import statistics as stats





#----------------------------------------------------------------------------#
'''
Asking the user to input the tab delimited text file containing all of the 
data exported from paraFoam. Before using this program this should be altered
correctly (see top).
'''
data_file = input('Enter a filename to read in: ')





#----------------------------------------------------------------------------#
"""
Creating a list of the positions along the blood vessel which we want to
sample for their flow profiles (z-velocity components).
"""

#Asking the user to input the length of the vessel (starting at the inflow)
#which they want to study. Then asking how many profiles they want to form.
length_of_study = float(input('Enter a length of the cylinder to study: '))
no_of_intervals = int(input('Enter the number of intervals to create: '))
interval_length = length_of_study / no_of_intervals


positions_wanted = []     #Initialising the list of desired flow profiles

#Looping over the number of intervals +1, as this accounts for the zero'th
#profile formed at the inflow.
for i in range((no_of_intervals + 1)):
    
    #Calculating the position of the flow profile and appending it
    profile_position = interval_length * i
    positions_wanted.append(profile_position)










#----------------------------------------------------------------------------#
"""
Creating a list of all z-coordinates in the positions file supplied, in the 
order in which they appear. Then doing the same for the z-components of 
velocity. Maintaining this order is important so that the entries are directly 
comparable.
"""
with open(data_file, 'r') as data:
        
    #Initialising the lists
    formatted_file = []
    z_coordinates = []
    z_velocities = []
    
    #Turning the file into a list of lists
    #This means we can iterate over a range equal to the size of the file in 
    #the next loop, rather than the lines in the file directly
    for line in data:
        formatted_file.append(str(line))
    
    #This loop actually pulls the data out of the files lines
    #Loops through the length of the entire file
    for i in range(len(formatted_file)):
        
        #Putting the line into a variable, then sanitising it, splitting the 
        #single string up into a list of individual entries, formated as 
        #strings.
        line = formatted_file[i]
        sanitised_line = [str(a) for a in line.strip().split()]
        
        #Pulling out the entries wanted, formatting them as floats, then 
        #appending them to their respective lists
        z_pos = float(sanitised_line[-1])
        z_vel = float(sanitised_line[3])
        z_coordinates.append(z_pos)
        z_velocities.append(z_vel)










#----------------------------------------------------------------------------#
"""
Clearly, it is unlikely that the desired intervals input by the user will fall
directly on cells, where data is calculated and held. Therefore, we need to map
each of the desired positions onto the closest location which contains data.
This method means that some points will be repeated, especially if the 
intervals formed are more dense than the mesh iteslf. This isn't a problem, as
the points will just be plotted on top of each other. A list of corrected 
flow profile locations is produced.
"""

corrected_desired_positions = []     #initialising empty list


#Loops over each of the locations to be investigated for their flow profile
for i in positions_wanted:
    
    
    #Initialising the delta variable as a very large number that will 
    #immediately be overwritten, but is non zero so as not to trip the loop on 
    #the first step
    delta = 1e10
    
    #Loops through all of the z-coordinates
    for coordinate in z_coordinates:
        
        #If the current coordinate produces a delta which shows it's closer 
        #than the current closest coordinate, it overwrites this and becomes 
        #the new closest coordinate. The new smallest delta also overwrites the
        #old one. If it's not closer than the current closest then the if 
        #statement is skipped
        if abs(coordinate - i) < delta:
            closest_position = coordinate
            delta = abs(coordinate - i)
    
    #Once all coordinates have been iterated through, the closest one is 
    #appended to the corrected list of flow profiles to investigate
    corrected_desired_positions.append(closest_position)

        
        
    
    
    
    
        
            
    
#----------------------------------------------------------------------------# 
"""
Find the corresponding z-velocities (to form the flow profile) for each of the
corrected profile positions. Record the position in the the coordinates list
where these occur, so later on we can investigate these positions in the 
velocities list.
"""
matching_entries_overall = []     #Initialising the empty list


#Iterates over each of the corrected locations, where available flow profile 
#data was found to exist
for position_i in corrected_desired_positions:
    
    
    matching_entries = []     #Initialising the empty list
    
    
    #At each location in the overall for loop, this sub-loop iterates over a 
    #range the size of the coordinates list
    for i in range(len(z_coordinates)):
        
        #Every time an entry in the coordinates list is found to match the
        #place we're investigating, it's position in the data file is added 
        #to a list 
        if z_coordinates[i] == position_i:
            matching_entries.append(i)
            
    
    #The overall matching entries list
    #This is a list of lists
    #Each individual list is all the lines in the data file where the the z 
    #coordinate matched the one to be investigated, and there will therefore 
    #be a corresponding velocity at this position
    #This was repeated for each z-coordinate to be investigated, so there is 
    #a list of positions within the data file for each flow profiles to be 
    #investigated
    matching_entries_overall.append(matching_entries)










#----------------------------------------------------------------------------
"""
Now we know all of the lines in the data file to look for, for each of the flow
profiles we're interested in, we can go in and find the corresponding 
velocities. The block of code below takes a list of file locations (for a flow
profile position), goes into the file and builds up a list of the corresponding
velocities. The list built is itself then appended to the overall list. This 
whole process is repeated for every flow profile (and its corresponding list of
data file positions).
"""
cross_section_velocities_overall = []     #Initialising the empty list


#Each iteration of the loop sets the iteration variable as the list of file 
#positions for that flow profile
#The next iteration will use the list of file positions for the next flow 
#profile
for file_locations in matching_entries_overall:
    
    cross_section_velocities = []     #Initialising the empty list
    
    
    #Run through each of the individual file locations, and append the velocity
    #value found there
    for location in file_locations:
        cross_section_velocities.append(z_velocities[location])
    
    
    #Append the whole list of corresponding velocities itself to the overall 
    #list
    cross_section_velocities_overall.append(cross_section_velocities)










#----------------------------------------------------------------------------#
"""
Producing a list of the average velocity across each of the flow profiles 
investigated. Does this using the array of inidividual cell velocities already 
produced.
"""

cross_section_av_velocities = []     #Initialising the empty list


#Loops through the entire array of velocities produced
#Each entry in this list iterated through is itself a list of velocities in the
#flow profile at that position
for i in range(len(cross_section_velocities_overall)):
    
    #Putting the list of velocities at across this flow profile into a list 
    #variable 'n'
    n = cross_section_velocities_overall[i]
    
    #Resetting the total after the previous iteration
    total = 0
    
    #Running through the list of velocities and totalling it up
    for a in range(len(n)):
        total += n[a]
    
    #Calculating the average for this flow profile and appending it to the list
    av = total/len(n)
    cross_section_av_velocities.append(av)










#----------------------------------------------------------------------------#
"""
Plotting & saving the graph
"""

plt.scatter(corrected_desired_positions, cross_section_av_velocities)

plt.title('Change in flow profile over longitudinal distance travelled')
plt.xlabel('Y-position [m]')
plt.ylabel('Average Uz across all cells in cross section [m/s]')
plt.xlim(0, max(corrected_desired_positions))
plt.ylim(0.13, 0.19) #For 15m/s flow
#plt.ylim(0.09, 0.13) #For 10m/s flow
plt.grid(which='major', linestyle='-', linewidth='0.7')
plt.grid(which='minor', linestyle='dashed', linewidth='0.4')
plt.savefig(('Flow profile development' + '.pdf'))
plt.show()









#----------------------------------------------------------------------------#
"""
Calculating the position along the blood vessel where fully developed flow is 
reached. This is defined using a user specified tolerance. This is a tolerance
of the percentage slope in average velocity between flow profiles. The result
produced is an objective measure of when fully-developed flow is reached,
which is comparable between different mesh densities, where points on the graph
will be more/less densely packed.
"""

#Asking the user for their tolerance to determine when fully developed is reached
tolerance = float(input('Enter a percentage tolerance for the rate of change in average velocity before flow is considered fully developed: '))


#Initialising the slope variable as a very large number that will immediately 
#be overwritten, but is non zero so as not to trip the loop on the first step
percentage_slope = 1e10


#Loop iterates through a range of numbers the size of the number of points
#plotted
for i in range(len(cross_section_av_velocities) -1):

    #Creating a variable for the average velocity across the current profile
    #and the next
    v = cross_section_av_velocities[i]
    v1 = cross_section_av_velocities[i+1]
    
    #Creating a variable for the z-position at the current profile and the next
    z = corrected_desired_positions[i]
    z1 = corrected_desired_positions[i+1]
    
    
    #If the number of intervals asked for exceeds the number of cells in the 
    #z-direction, there will be multiple points plotted for each cell. We want 
    #to only analyse when it has actually moved to the next point
    if not z == z1:
        
        delta_velz = v1 - v
        delta_z = z1 - z
        
        percentage_slope = (abs(delta_velz) / delta_z) * 100
    
    
    #If the percentage slope between profile positions falls below the input
    #tolerance we print the location and average velocity here, before breaking
    #the loop 
    if percentage_slope < tolerance:
        print('Flow is considered fully developed beyond z= ', corrected_desired_positions[i], ' m.', sep='')
        print('Average z velocity here is Uz= ', cross_section_av_velocities[i], ' m/s.', sep='')
        print('The maximum outlet velocity is ', max(cross_section_velocities_overall[len(cross_section_velocities_overall)-1]), ' m/s.')
        print('The mean outlet velocity is ', stats.mean(cross_section_velocities_overall[len(cross_section_velocities_overall)-1]), ' m/s.')
        break
    
    #If the percentage slope between profile positions never falls below the 
    #input tolerance (loop not broken on the final iteration) we print this as 
    #a message
    if i == (len(cross_section_av_velocities) -2):
        print('Flow does not reach fully developed within the length of study.')